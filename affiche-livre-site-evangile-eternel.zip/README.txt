INSTRUCTIONS

1. Envoyez le dossier images dans votre site.
2. Collez le contenu du fichier code-a-coller.html dans votre index.html.
3. Placez le bloc HTML à l’endroit où vous voulez voir l’affiche.
4. Placez le bloc CSS dans votre style.css ou dans la balise <style> de votre index.html.

Fichiers inclus :
- images/affiche-livre.webp
- images/affiche-livre.jpg
- images/affiche-livre.png
- code-a-coller.html
