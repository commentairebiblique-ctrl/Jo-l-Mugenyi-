# Sécurité du paiement

## Carte bancaire

Ne demandez jamais directement au client :

- Numéro de carte bancaire
- CVV
- Code PIN
- Mot de passe

Utilisez une passerelle de paiement officielle.

## Mobile Money

Pour M-Pesa et Airtel Money, le site demande seulement :

- Nom
- Email
- Téléphone
- Montant

La confirmation du paiement doit se faire sur le téléphone du client.

## Clés API

Les clés M-Pesa et Airtel doivent rester dans Render > Environment Variables.
Ne les mettez jamais dans GitHub si elles sont réelles.
