/**
 * Serveur de paiement sécurisé — Évangile Éternel
 * ------------------------------------------------
 * Ce serveur permet à Render d’héberger le site et de préparer
 * les routes de paiement Mobile Money M-Pesa et Airtel Money.
 *
 * Important :
 * - Ne mettez jamais vos clés API dans index.html.
 * - Gardez les clés secrètes dans les variables d’environnement Render.
 */

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("."));

function createReference(prefix) {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function validatePaymentInput(req, res, next) {
  const { fullName, email, phone, amount } = req.body;

  if (!fullName || !email || !phone || !amount) {
    return res.status(400).json({
      success: false,
      message: "Nom, email, téléphone et montant sont obligatoires."
    });
  }

  if (!/^\d{10,15}$/.test(String(phone).replace(/\D/g, ""))) {
    return res.status(400).json({
      success: false,
      message: "Numéro de téléphone invalide. Exemple : 2438XXXXXXXX."
    });
  }

  next();
}

app.post("/api/payments/mpesa", validatePaymentInput, async (req, res) => {
  const reference = createReference("MPESA");

  try {
    const required = [
      "MPESA_BASE_URL",
      "MPESA_API_KEY",
      "MPESA_PUBLIC_KEY",
      "MPESA_SHORTCODE",
      "MPESA_CALLBACK_URL"
    ];

    const missing = required.filter((key) => !process.env[key]);
    if (missing.length) {
      return res.status(503).json({
        success: false,
        reference,
        message: `Configuration M-Pesa manquante : ${missing.join(", ")}. Ajoutez ces valeurs dans Render > Environment.`
      });
    }

    /*
      Ici, il faut mettre l’appel API officiel reçu de Vodacom M-Pesa.
      Les clés doivent rester dans Render > Environment Variables.
    */

    return res.json({
      success: true,
      mode: "TEST",
      provider: "M-Pesa Vodacom",
      reference,
      message: "Paiement M-Pesa simulé. Ajoutez l’appel API officiel pour activer le vrai paiement."
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      reference,
      message: error.message || "Erreur serveur M-Pesa."
    });
  }
});

app.post("/api/payments/airtel", validatePaymentInput, async (req, res) => {
  const reference = createReference("AIRTEL");

  try {
    const required = [
      "AIRTEL_BASE_URL",
      "AIRTEL_CLIENT_ID",
      "AIRTEL_CLIENT_SECRET",
      "AIRTEL_CALLBACK_URL"
    ];

    const missing = required.filter((key) => !process.env[key]);
    if (missing.length) {
      return res.status(503).json({
        success: false,
        reference,
        message: `Configuration Airtel manquante : ${missing.join(", ")}. Ajoutez ces valeurs dans Render > Environment.`
      });
    }

    /*
      Ici, il faut mettre l’appel API officiel reçu de Airtel Money.
      Les clés doivent rester dans Render > Environment Variables.
    */

    return res.json({
      success: true,
      mode: "TEST",
      provider: "Airtel Money",
      reference,
      message: "Paiement Airtel Money simulé. Ajoutez l’appel API officiel pour activer le vrai paiement."
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      reference,
      message: error.message || "Erreur serveur Airtel Money."
    });
  }
});

app.post("/api/webhooks/mpesa", (req, res) => {
  console.log("Callback M-Pesa reçu :", req.body);
  res.json({ received: true });
});

app.post("/api/webhooks/airtel", (req, res) => {
  console.log("Callback Airtel reçu :", req.body);
  res.json({ received: true });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Serveur Évangile Éternel lancé : http://localhost:${port}`);
});
