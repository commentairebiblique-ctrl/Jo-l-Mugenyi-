# Évangile Éternel — Site eBook

Site web pour présenter et vendre le livre :

**Commentaire de toute la Bible — Évangile Éternel**

## Fichiers du projet

- `index.html` : page principale du site
- `server.js` : serveur Node.js pour Render
- `package.json` : configuration Node.js
- `.env.example` : modèle des variables secrètes
- `SECURITY.md` : conseils de sécurité

## Déploiement sur Render

Dans Render, créer un **New Web Service**, connecter ce dépôt GitHub, puis mettre :

```txt
Build Command:
npm install
```

```txt
Start Command:
npm start
```

## Variables secrètes à ajouter dans Render

Dans Render > Environment Variables, ajouter :

```txt
MPESA_BASE_URL
MPESA_API_KEY
MPESA_PUBLIC_KEY
MPESA_SHORTCODE
MPESA_CALLBACK_URL
AIRTEL_BASE_URL
AIRTEL_CLIENT_ID
AIRTEL_CLIENT_SECRET
AIRTEL_CALLBACK_URL
```

## Important

Le paiement Mobile Money direct exige un compte marchand officiel M-Pesa Vodacom et Airtel Money.
Les clés API ne doivent jamais être écrites dans `index.html`.
